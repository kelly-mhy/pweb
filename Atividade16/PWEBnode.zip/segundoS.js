console.log('1');
t();
console.log('3');
function t(){
    console.log('2');
}

/* este exemplo demonstra a execução síncrona. O retorno será:
PS C:\PwebNode\Exercicios> node segundoS
1
2
3
*/