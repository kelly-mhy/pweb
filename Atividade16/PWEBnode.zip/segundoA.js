console.log('1');
t();
console.log('3');
function t() {
    setTimeout(function() {
        console.log('2');
    }, 10);
}

/* este exemplo demonstra a execução assíncrona. Não pára de fazer algo. 
Imprimiu o 1, chama o 2, enquanto ele roda o 2, já roda o 3, e já dá o retorno do 3 enquanto isso.
O retorno será:
PS C:\PwebNode\Exercicios> node segundoA
1
3
2
*/