var soma = 0;
for (var i=2; i<=process.argv.length-1; i++)
    soma=soma+Number(process.argv[i]);
console.log("soma = " +soma);

/* Digitar
node terceiro 1 2 3
0    1        2 3 4 - argumentos
var comeca de 2 porque comeca dos argumentos digitados (1 2 3) e vai até o tamanho-1, somando tudo
resultado === soma=6
*/

