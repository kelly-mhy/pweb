console.log('primeiro exemplo');

// criar o arquivo .js
// abrir Terminal, no menu, para abrir o prompt
// no prompt, para rodar digitar: node primeiro
// retorno: primeiro exemplo