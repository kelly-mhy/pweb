const fs = require('fs'); // incluir o modulo file system
const data = fs.readFileSync('file.txt.txt'); // leia o arquivo file.txt de forma síncrona e jogue na const data
// a execução é bloqueada aqui até o arquivo ser lido
console.log(data.toString());
